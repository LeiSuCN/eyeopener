/**
 * eyeopener全局配置文件
 * 2015/10/24 宿磊
 */

// controllers模块
angular.module('eyeopener.controllers', []);